/// <reference types="cypress" />

describe('Doação', () => {
    it('devem poder realizar um cadastro', () => {
        cy.visit('https://doacao-projetoti.vercel.app/inicial.html');
        // cy.get - busca um elemento
        // .type - insere um texto
        cy.get('.d-grid > :nth-child(2)').click();

        Cypress.on('uncaught:exception', (err, runnable) => {
            // returning false here prevents Cypress from
            // failing the test
            return false
          })
          
          it('fails to visit website 1', function () {
            cy.visit('https://doacao-projetoti.vercel.app/loginCliente.html')
          })

          cy.get('.button-login > .d-grid > .btn-lg').click();

          cy.get('#nome').type('Ana');
          cy.get('#tel').type('31985958695');
          cy.get('#email').type('lucasmg569@gmail.com');

          cy.get('.form-group > .d-grid > .btn-lg').click();

          cy.get('#senha').type('123456');
          cy.get('#confirmaSenha').type('123456');

          cy.get('.btn-lg').click();

          cy.get('#email').type('lucasmg569@gmail.com');
          cy.get('#password').type('123456');

          cy.get('.form-group > .d-grid > .btn-lg').click();
          cy.get('[href="cadastrar-doacoes.html"]').click();

          cy.get('#itens').select('Medicamentos');
          cy.get('#datepicker').click();
          cy.get(':nth-child(2) > :nth-child(2) > .ui-state-default').click();
          cy.get('#horario').select('09:00');
          cy.get('#description').type('Siprac');

          cy.get('#cadastrar').click();
          cy.get('#close-button').click();
          cy.visit('https://doacao-projetoti.vercel.app/pagina-inicial.html');
        });
    });
